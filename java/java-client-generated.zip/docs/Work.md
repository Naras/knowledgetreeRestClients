# Work

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**getId** | **String** |  |  [optional]
**legacyid** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**tags** | **List&lt;String&gt;** |  |  [optional]
**components** | [**List&lt;WorkComponent&gt;**](WorkComponent.md) |  |  [optional]
**workRelations** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**workParents** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**personParents** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**subjectParents** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
