# LinkRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sourceid** | **String** |  |  [optional]
**targetid** | **String** |  |  [optional]
