# PersonRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**birthdate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**deathdate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**alive** | **Boolean** |  |  [optional]
**biography** | **String** |  |  [optional]
**period** | **String** |  |  [optional]
**affiliation** | **String** |  |  [optional]
**address** | [**Address**](Address.md) |  |  [optional]
