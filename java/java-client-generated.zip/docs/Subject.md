# Subject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**getId** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**description** | **String** |  |  [optional]
**subjectRelations** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**subjectParents** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
**subjectWorkRelations** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
