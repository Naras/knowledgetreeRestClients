# WorkComponent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]
**langcode** | **String** |  |  [optional]
**scriptcode** | **String** |  |  [optional]
**body** | **String** |  |  [optional]
**hyperlink** | **String** |  |  [optional]

<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
TEXT | &quot;TEXT&quot;
AUDIO | &quot;AUDIO&quot;
VIDEO | &quot;VIDEO&quot;
