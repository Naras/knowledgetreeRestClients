# Problem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**title** | **String** |  |  [optional]
**status** | **Integer** |  |  [optional]
**detail** | **String** |  |  [optional]
**instance** | **String** |  |  [optional]
