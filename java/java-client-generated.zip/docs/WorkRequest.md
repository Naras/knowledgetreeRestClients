# WorkRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** |  |  [optional]
**tags** | **List&lt;String&gt;** |  |  [optional]
**components** | [**List&lt;WorkComponent&gt;**](WorkComponent.md) |  |  [optional]
