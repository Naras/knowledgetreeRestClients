# SubjectResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subject** | [**Subject**](Subject.md) |  |  [optional]
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
