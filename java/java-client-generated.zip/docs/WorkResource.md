# WorkResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**work** | [**Work**](Work.md) |  |  [optional]
**links** | [**List&lt;Link&gt;**](Link.md) |  |  [optional]
