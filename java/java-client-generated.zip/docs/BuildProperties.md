# BuildProperties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**version** | **String** |  |  [optional]
**group** | **String** |  |  [optional]
**artifact** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
