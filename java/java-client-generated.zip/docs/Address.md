# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**state** | **String** |  |  [optional]
**district** | **String** |  |  [optional]
**zipcode** | **String** |  |  [optional]
**address** | **String** |  |  [optional]
**country** | **String** |  |  [optional]
