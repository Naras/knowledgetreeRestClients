# PersonRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**birthdate** | **datetime** |  | [optional] 
**deathdate** | **datetime** |  | [optional] 
**alive** | **bool** |  | [optional] 
**biography** | **str** |  | [optional] 
**period** | **str** |  | [optional] 
**affiliation** | **str** |  | [optional] 
**address** | [**Address**](Address.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

