# WorkComponent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] 
**langcode** | **str** |  | [optional] 
**scriptcode** | **str** |  | [optional] 
**body** | **str** |  | [optional] 
**hyperlink** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

