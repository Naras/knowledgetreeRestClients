# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**state** | **str** |  | [optional] 
**district** | **str** |  | [optional] 
**zipcode** | **str** |  | [optional] 
**address** | **str** |  | [optional] 
**country** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

