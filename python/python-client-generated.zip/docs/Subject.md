# Subject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**get_id** | **str** |  | [optional] 
**title** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**subject_relations** | [**list[Link]**](Link.md) |  | [optional] 
**subject_parents** | [**list[Link]**](Link.md) |  | [optional] 
**subject_work_relations** | [**list[Link]**](Link.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

